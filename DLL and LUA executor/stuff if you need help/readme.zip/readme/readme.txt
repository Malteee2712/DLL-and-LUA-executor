made by discord:malte.27

creds to malte27

all rights deserved 2025 

have fun with this shi XD